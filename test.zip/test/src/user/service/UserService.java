package user.service;

import org.springframework.stereotype.Service;

import user.vo.LoginDTO;
import user.vo.UsersVO;

@Service
public interface UserService {

	void register(UsersVO usersVO) throws Exception;	
	UsersVO login(LoginDTO loginDTO) throws Exception;
}
