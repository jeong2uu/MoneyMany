package user.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import user.dao.UserDAO;
import user.vo.LoginDTO;
import user.vo.UsersVO;



@Repository
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;
	
	

	public UserServiceImpl(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	
	@Override
	public void register(UsersVO usersVO) throws Exception {
		// TODO Auto-generated method stub
		userDAO.register(usersVO);
	}

	@Override
	public UsersVO login(LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		return userDAO.login(loginDTO);
	}
	
	



}
