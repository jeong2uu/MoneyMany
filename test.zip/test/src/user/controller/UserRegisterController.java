package user.controller;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import user.service.UserService;
import user.vo.UsersVO;

@Controller
@RequestMapping("/view")
public class UserRegisterController {

	@Autowired
	private UserService userService;
	

	public UserRegisterController(UserService userService) {
		this.userService = userService;
	}
	
	//ȸ������ ������
	@RequestMapping(value = "register.do", method = RequestMethod.GET)
	public String registerGET() throws Exception {
		
		return "/register";
	}
	
	//ȸ������ ó��
	@RequestMapping(value = "registerSuccess.do", method = RequestMethod.POST)
	public String registerPOST(UsersVO usersVO, RedirectAttributes redirectAttributes) throws Exception {
		
		String hashedPw = BCrypt.hashpw(usersVO.getUserPw(), BCrypt.gensalt());
		usersVO.setUserPw(hashedPw);
		userService.register(usersVO);
		redirectAttributes.addFlashAttribute("msg", "REGISTERED");
		
		
		return "/login";
	}

	
	
}
