CREATE TABLE users (
	user_id VARCHAR2(60) PRIMARY KEY,
	user_pw VARCHAR2(60) NOT NULL,
	user_pw_q VARCHAR2(100) NOT NULL,
	user_pw_a VARCHAR2(60) NOT NULL,
	user_school VARCHAR2(30) NOT NULL,
	user_number VARCHAR2(80) NOT NULL,
	user_name VARCHAR2(20) NOT NULL,
	user_gender CHAR NOT NULL,
	user_phone NUMBER NOT NULL,
	user_address VARCHAR2(100) NOT NULL,
	user_email VARCHAR2(80) NOT NULL,
	user_department VARCHAR2(40) NOT NULL,
	user_point NUMBER NULL
)

INSERT INTO users VALUES ('atuozzang', 'wannabe', '��й�ȣ����', '��A��ȣ�亯', '�밡��', 1, 'õ����', 'M', 1, '�ּ�', '�̸���', 1, 0)
DELETE FROM users WHERE user_id = 'atuozzang';
DELETE FROM users WHERE user_id = 'dkdlel3';


ALTER TABLE users RENAME COLUMN user_birth TO user_department
ALTER TABLE users MODIFY user_department VARCHAR2(40);
ALTER TABLE users MODIFY user_number VARCHAR2(80);