CREATE TABLE tbl_member(
	user_id NUMBER PRIMARY KEY,
	user_pw VARCHAR2(20),
	user_name VARCHAR2(20),
	user_email  VARCHAR2(30),
	user_regdate VARCHAR2(20),
	user_updatedate VARCHAR2(30)
);

CREATE SEQUENCE tbl_member_seq;