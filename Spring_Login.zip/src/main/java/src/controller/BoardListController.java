package src.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import src.service.*;
import src.vo.*;

@Controller
public class BoardListController {
	
	@Autowired
	private src.service.BoardListService boardListService;
	//�ڵ�����
	
	@RequestMapping("/board_list.do")
	public ModelAndView viewBoardList() {
		ModelAndView mav = new ModelAndView();
		List<src.vo.Board> boardList = boardListService.getBoardList();
		mav.setViewName("boardList");
		mav.addObject("boardList", boardList);
	//����
		return mav;
	}
	
}
