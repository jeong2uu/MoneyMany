package src.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import src.service.*;
import src.vo.*;


@Controller
public class BoardUpdateController {

		@Autowired
		private src.service.BoardUpdateService boardUpdateService;
		
		@RequestMapping("/board_update_action.do")
		public String updateBoard(src.vo.Board board) {
			boardUpdateService.modifyBoard(board);
			return "redirect:/board_list.do";
		}
}
