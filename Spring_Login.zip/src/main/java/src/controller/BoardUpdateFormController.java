package src.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import src.service.*;
import src.vo.*;

@Controller
public class BoardUpdateFormController {

		@Autowired
		private src.service.BoardUpdateFormService boardUpdateFormService;
		
		@RequestMapping("/board_updateForm.do")
		public ModelAndView viewUpdateForm(@RequestParam int seq) {
			ModelAndView mav = new ModelAndView();
			src.vo.Board board = boardUpdateFormService.getOldBoard(seq);
			
			mav.setViewName("boardUpdateForm");
			mav.addObject("board", board);
			return mav;
		}
		
}
