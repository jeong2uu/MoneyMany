package src.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.dao.BoardDAO;
import src.vo.*;

@Service
public class BoardListService {
	//�ڵ�����
	@Autowired
	private src.dao.BoardDAO boardDAO;
	
	//�޼ҵ�ȣ��
	public List<src.vo.Board> getBoardList() {
		// TODO Auto-generated method stub
		List<Board> boardList = boardDAO.selectBoardList();
		return boardList;
	}

}
