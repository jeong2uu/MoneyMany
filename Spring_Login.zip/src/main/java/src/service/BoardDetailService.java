package src.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.dao.BoardDAO;
import src.vo.*;

@Service
public class BoardDetailService {
	@Autowired
	private src.dao.BoardDAO boardDAO;
	
	
	public src.vo.Board getBoardDetail(int seq) {
		// TODO Auto-generated method stub
		src.vo.Board board = boardDAO.selectBoard(seq);
		return board;
	}

}
