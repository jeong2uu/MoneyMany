package src.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.dao.BoardDAO;
import src.vo.*;

@Service
public class BoardUpdateFormService {
	@Autowired
	private src.dao.BoardDAO boardDAO;
	
	public src.vo.Board getOldBoard(int seq) {
		// TODO Auto-generated method stub
		src.vo.Board board = boardDAO.selectOldBoard(seq);
		
		return board;
	}

}
