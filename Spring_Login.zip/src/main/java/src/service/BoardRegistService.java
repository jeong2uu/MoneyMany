package src.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.dao.BoardDAO;
import src.vo.*;

@Service
public class BoardRegistService {

	@Autowired
	private src.dao.BoardDAO boardDAO;
	
	public void registArticle(src.vo.Board board) {
		// TODO Auto-generated method stub
		boardDAO.insertArticle(board);
	}

}
