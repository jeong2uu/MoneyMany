package user.controller;

import java.util.Date;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.WebUtils;

import user.service.UserService;
import user.vo.UsersVO;

@Controller
@RequestMapping("/view")
public class UserLogoutController {

	@Autowired
	private UserService userSerivce;
	
	
	
	public UserLogoutController(UserService userService) {
		this.userSerivce = userService;
	}
	
	@RequestMapping(value= "/logout.do", method = RequestMethod.GET) 
	public String logout(HttpServletRequest request,
			HttpServletResponse response, 
			HttpSession session) throws Exception {
		
		Object object = session.getAttribute("login");
		if(object != null) {
			session.removeAttribute("login");
			session.invalidate();
			Cookie loginCookie = WebUtils.getCookie(request, "loginCookie");
			
			if(loginCookie != null) {
				loginCookie.setPath("/");
				loginCookie.setMaxAge(0);
				response.addCookie(loginCookie);
				
			}
		}
		
		
		return "start";
		
		
	}
	
	
	
	
	

}
