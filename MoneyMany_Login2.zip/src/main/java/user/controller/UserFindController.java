package user.controller;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import user.service.UserService;
import user.vo.LoginDTO;
import user.vo.UsersVO;

@Controller
@RequestMapping("/view")
public class UserFindController {

	@Autowired
	private UserService userService;
	
	public UserFindController(UserService userService) {
		this.userService = userService;
	}
	
	//���̵� ã�� ������
	@RequestMapping(value = "findID.do", method = RequestMethod.GET)
	public ModelAndView findIDGET() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("findID");	
		
		return mav;
	}
	
	
    // ���̵� ã�� 
	@RequestMapping(value="IDcheck.do", method=RequestMethod.POST)
	public ModelAndView findIdAction(UsersVO vo){
		ModelAndView mav = new ModelAndView();
		UsersVO usersVO = userService.findId(vo);
		
		if(usersVO == null) { 
			mav.addObject("check", 1);
		} else { 
			mav.addObject("check", 0);
			mav.addObject("id", usersVO.getUserId());
		}
		mav.setViewName("IDPost");
		
		return mav;
	}
	
	
	//��й�ȣ ã�� ������
	@RequestMapping(value = "findPW.do", method = RequestMethod.GET)
	public ModelAndView findPWGET() {
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("findPW");	
		
		return mav;
	}
	
    // ��й�ȣ ã�� ����
	@RequestMapping(value="PWcheck.do", method=RequestMethod.POST)
	public ModelAndView findPwAction(UsersVO vo){
		ModelAndView mav = new ModelAndView();
		UsersVO usersVO = userService.findPassword(vo);
		
		if(usersVO == null) { 
			mav.addObject("check", 3);

		} else { 
			mav.addObject("check", 2);
			mav.addObject("user", usersVO);//user
		}
		mav.setViewName("PWPost");
		
		return mav;
	}
	
	// ��й�ȣ �ٲٱ� ����
	@RequestMapping(value="updatePw.do", method=RequestMethod.POST)
	public String updatePasswordAction(@ModelAttribute UsersVO vo, Model model) {

			String hashedPw = BCrypt.hashpw(vo.getUserPw(), BCrypt.gensalt());
			vo.setUserPw(hashedPw);
		
			userService.updatePassword(vo);
			model.addAttribute("check", 4);
			
			
			return "login";
	
	}
		
		
}
