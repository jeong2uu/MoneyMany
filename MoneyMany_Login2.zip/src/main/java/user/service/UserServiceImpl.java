package user.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import user.dao.UserDAO;
import user.vo.LoginDTO;
import user.vo.UsersVO;


@Service("userService")
@Repository
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;
	
	

	public UserServiceImpl(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	
	@Override
	public void register(UsersVO usersVO) throws Exception {
		// TODO Auto-generated method stub
		userDAO.register(usersVO);
	}

	@Override
	public UsersVO login(LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		return userDAO.login(loginDTO);
	}
	
	@Override
	public UsersVO findId(UsersVO vo) {
		// TODO Auto-generated method stub
		
		return userDAO.findId(vo);
	}

	@Override
	public UsersVO findPassword(UsersVO vo){
		// TODO Auto-generated method stub
		return userDAO.findPassword(vo);
	}

	@Override
	public void updatePassword(UsersVO vo) {
		// TODO Auto-generated method stub
		userDAO.updatePassword(vo);	
	}




}
