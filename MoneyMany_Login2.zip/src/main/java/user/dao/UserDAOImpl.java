package user.dao;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import user.vo.LoginDTO;
import user.vo.UsersVO;

@Repository
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SqlSession sqlSession;
	

	public UserDAOImpl(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
		
	@Override
	public void register(UsersVO usersVO) throws Exception {
		// TODO Auto-generated method stub
		sqlSession.insert("user.mybatis.UserMapper" + ".register", usersVO);
	}

	@Override
	public UsersVO login(LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		
		return sqlSession.selectOne("user.mybatis.UserMapper" + ".login", loginDTO);
	}
	
	@Override
	public UsersVO findId(UsersVO usersVO) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("user.mybatis.UserMapper" + ".findID", usersVO);
	}

	@Override
	public UsersVO findPassword(UsersVO usersVO) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("user.mybatis.UserMapper" + ".findPassword", usersVO); 
	}
	
	
	public void updatePassword(UsersVO usersVO) {
		sqlSession.update("user.mybatis.UserMapper" + ".updatePassword", usersVO);
	}
	
	
}
