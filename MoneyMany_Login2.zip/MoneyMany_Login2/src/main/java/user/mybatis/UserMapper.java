package user.mybatis;

import user.vo.LoginDTO;
import user.vo.UsersVO;

public interface UserMapper {
	void register(UsersVO usersVO) throws Exception;
	UsersVO login(LoginDTO loginDTO) throws Exception;
}
