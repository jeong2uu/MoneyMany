package user.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import user.service.UserService;
import user.vo.LoginDTO;
import user.vo.UsersVO;

@Controller
@RequestMapping("/view")
public class UserLoginController extends HandlerInterceptorAdapter {

	@Autowired
	private UserService userSerivce;
	
	
	
	public UserLoginController(UserService userService) {
		this.userSerivce = userService;
	}
	
	
	
	
	//�α��� ������
	@RequestMapping(value = "login.do", method = RequestMethod.GET)
	public String loginGET(@ModelAttribute("loginDTO") LoginDTO loginDTO) {
		return "login";
	}
	

	//�α��� ó��
	@RequestMapping(value = "loginPost.do", method = RequestMethod.POST) 
	public ModelAndView loginPOST(@RequestParam("id") String id, @RequestParam("pw") String pw,
			LoginDTO loginDTO, HttpSession httpSession, Model model) throws Exception {
		
		loginDTO.setUserId(id);
		loginDTO.setUserPw(pw);
		loginDTO.setUserCookie(false);
		
		UsersVO usersVO = userSerivce.login(loginDTO);
		ModelAndView mav = new ModelAndView();
		
		if(usersVO == null || !BCrypt.checkpw(loginDTO.getUserPw(), usersVO.getUserPw())) {
			mav.setViewName("loginPost");
		}
		else {
		mav.addObject("login", usersVO);
		mav.setViewName("index");
		}
		return mav;
		
	}
	//�ٸ� ������ �Ѿ�� �α��� �����ϱ�
	private static final String LOGIN = "login";
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession httpSession = request.getSession();
		
		if(httpSession.getAttribute(LOGIN) != null) {
			httpSession.removeAttribute(LOGIN);		
		}
		return true;
	} 
	
	
	  // ���̵� ã�� ������ �̵�
		@RequestMapping(value = "find_id_form.do", method = RequestMethod.GET)
		public String findIdView() {
			return "find_id_form";
		}
		
	    // ���̵� ã�� ����
		@RequestMapping(value="find_id", method=RequestMethod.POST)
		public String findIdAction(UsersVO vo, Model model,LoginDTO loginDTO) {
		
			UsersVO user = userSerivce.findId(vo);
			
			
			if(user == null) { 
				model.addAttribute("check", 1);
			} else { 
				model.addAttribute("check", 0);
				model.addAttribute("id", loginDTO.getUserId());
			}
			
			return "findId";
		}
		
	 
	
	
}
