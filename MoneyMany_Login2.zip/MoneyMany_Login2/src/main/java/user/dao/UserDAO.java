package user.dao;

import user.vo.LoginDTO;
import user.vo.UsersVO;

public interface UserDAO {
	void register(UsersVO usersVO) throws Exception;
	UsersVO login(LoginDTO loginDTO) throws Exception;
}
