package user.serivce;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import user.domain.LoginDTO;
import user.domain.UserVO;
import user.persistence.UserDAO;
@Service
public class UserServiceImpl implements UserService {
	
	  private final UserDAO userDAO;
	  
	@Autowired
   public UserServiceImpl(UserDAO userDAO) {
	        this.userDAO = userDAO;
	    }
	    
	    // ȸ�� ���� ó��
	    
	@Override
	public void register(UserVO userVO) throws Exception {
		// TODO Auto-generated method stub
		userDAO.register(userVO);

	}
	
	//ȸ�� ���� ���� ����
	@Override
	public UserVO login(LoginDTO loginDTO) throws Exception {
	    return userDAO.login(loginDTO);
	}

}
