package user.persistence;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import user.domain.LoginDTO;
import user.domain.UserVO;

public class UserDAOImpl implements UserDAO {
	
	private static final String NAMESPACE ="com.doubles.mvcboard.mappers.user.UserMapper";
	
	private final SqlSession sqlSession;//root-context.xml�� ���ø� ����
	
	@Autowired
	public UserDAOImpl(SqlSession sqlSession) {
		this.sqlSession=sqlSession;
	}
	
	//ȸ������ ó��
	@Override
	public void register(UserVO userVO) throws Exception {
		// TODO Auto-generated method stub
		sqlSession.insert(NAMESPACE+".register",userVO);
		
	}
	
	//�α��� ó��
	@Override
	public UserVO login(LoginDTO loginDTO) throws Exception {
	    return sqlSession.selectOne(NAMESPACE + ".login", loginDTO);
	}
};
