package moneymany.card.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import moneymany.card.mybatis.CardMapper;
import moneymany.card.vo.CardVO;

@Repository
public class CardDAOImpl implements CardDAO {

	@Autowired
	private SqlSession sqlSession;
	//SqlSessionTemplate�� SqlSession�� ������
	
	@Override
	public ArrayList<CardVO> getCards() {
		// TODO Auto-generated method stub
		CardMapper cardMapper = sqlSession.getMapper(CardMapper.class);
		//moneymany.card.mybatis.CardMapper�� getCard�޼ҵ� ����
		ArrayList<CardVO> cardList = cardMapper.getCards();
		//cardVO���� ����Ʈ��ü�� ����� cardMapper�� getCards�޼ҵ带 �����Ͽ� ���Ұ� ����
		return cardList;
	}
	
	@Override
	public void insertCard(CardVO cardVO) {
		// TODO Auto-generated method stub
		CardMapper cardMapper = sqlSession.getMapper(CardMapper.class);
		cardMapper.insertCard(cardVO);
	}
	
	@Override
	public void updateCard(CardVO cardVO) {
		// TODO Auto-generated method stub
		CardMapper cardMapper = sqlSession.getMapper(CardMapper.class);
		cardMapper.updateCard(cardVO);
	}
	
	@Override
	public void deleteCard(int id) {
		// TODO Auto-generated method stub
		CardMapper cardMapper = sqlSession.getMapper(CardMapper.class);
		cardMapper.deleteCard(id);
	}
	
	@Override
	public CardVO selectUpdateCard(int id) {
		// TODO Auto-generated method stub
		CardMapper cardMapper = sqlSession.getMapper(CardMapper.class);
		CardVO cardVO = cardMapper.getUpdateCard(id);
		return cardVO;
	}
	
}
