package moneymany.card.dao;

import java.util.ArrayList;

import moneymany.card.vo.CardVO;

public interface CardDAO {
	public ArrayList<CardVO> getCards();
	public void insertCard(CardVO cardVO);
	public void updateCard(CardVO cardVO);
	public void deleteCard(int id);
	public CardVO selectUpdateCard(int id);
}
