package moneymany.card.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import moneymany.card.service.CardService;
import moneymany.card.vo.CardVO;

@Controller
public class MybatisCardController extends HandlerInterceptorAdapter {
	
	@Autowired
	private CardService cardService;

	 public MybatisCardController(CardService cardService) { 
		 this.cardService = cardService; 
		 }
	 
	
	@RequestMapping("/start.do")
	public ModelAndView main() {
		ModelAndView mav = new ModelAndView();
		List<CardVO> cardList = cardService.getCards();
		mav.addObject("cardList", cardList);
		mav.setViewName("start");
		
		return mav;
	}
	
	@RequestMapping(value = "insert.do", method = RequestMethod.POST)
	public String addCard(CardVO cardVO) {
		cardService.addCard(cardVO);
		
		return "redirect:/start";
	}
	
	@RequestMapping(value = "delete.do")
	public String removeCard(@RequestParam("id") int id) {
		cardService.removeCard(id);
		
		return "redirect:/start";
	}
	
	@RequestMapping(value = "updateForm.do")
	public ModelAndView modifyForm(@RequestParam("id") int id) {
		ModelAndView mav = new ModelAndView();
		CardVO cardVO = cardService.getModifyCard(id);
		mav.addObject("cardVO", cardVO);
		mav.setViewName("updateForm");
		return mav;
	}
	
	@RequestMapping(value = "update.do", method = RequestMethod.POST)
	public String modifyCard(CardVO cardVO) {
		cardService.modifyCard(cardVO);
		return "redirect:/start";
	}
}
