package moneymany.card.service;

import java.util.ArrayList;

import moneymany.card.vo.CardVO;


public interface CardService {
	public ArrayList<CardVO> getCards();
	public void addCard(CardVO cardVO);
	public void removeCard(int id);
	public CardVO getModifyCard(int id);
	public void modifyCard(CardVO cardVO);
}
