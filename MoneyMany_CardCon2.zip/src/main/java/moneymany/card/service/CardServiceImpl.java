package moneymany.card.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import moneymany.card.dao.CardDAO;
import moneymany.card.vo.CardVO;

@Service
public class CardServiceImpl implements CardService {
	
	@Autowired
	private CardDAO cardDAO;
	
	@Override
	public ArrayList<CardVO> getCards() {
		// TODO Auto-generated method stub
		ArrayList<CardVO> cardList = cardDAO.getCards();
		return cardList;
	}
	
	@Override
	public void addCard(CardVO cardVO) {
		// TODO Auto-generated method stub
		cardDAO.insertCard(cardVO);
	}
	
	@Override
	public CardVO getModifyCard(int id) {
		// TODO Auto-generated method stub
		CardVO cardVO = cardDAO.selectUpdateCard(id);
		return cardVO;
	}
	
	@Override
	public void modifyCard(CardVO cardVO) {
		// TODO Auto-generated method stub
		cardDAO.updateCard(cardVO);
	}
	
	@Override
	public void removeCard(int id) {
		// TODO Auto-generated method stub
		cardDAO.deleteCard(id);
	}
	
}
