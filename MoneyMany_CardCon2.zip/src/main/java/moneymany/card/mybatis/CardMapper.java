package moneymany.card.mybatis;

import java.util.ArrayList;

import moneymany.card.vo.CardVO;

public interface CardMapper {
	public ArrayList<CardVO> getCards();
	public void insertCard(CardVO cardVO);
	public void updateCard(CardVO cardVO);
	public void deleteCard(int id);
	public CardVO getUpdateCard(int id);
}
