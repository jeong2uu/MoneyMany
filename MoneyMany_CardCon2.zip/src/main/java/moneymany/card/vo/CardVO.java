package moneymany.card.vo;

public class CardVO {
	private int id;
	private int card_num;
	private int cvc_num;
	private String card_bank;
	private String card_passwd;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCard_num() {
		return card_num;
	}
	public void setCard_num(int card_num) {
		this.card_num = card_num;
	}
	public int getCvc_num() {
		return cvc_num;
	}
	public void setCvc_num(int cvc_num) {
		this.cvc_num = cvc_num;
	}
	public String getCard_bank() {
		return card_bank;
	}
	public void setCard_bank(String card_bank) {
		this.card_bank = card_bank;
	}
	public String getCard_passwd() {
		return card_passwd;
	}
	public void setCard_passwd(String card_passwd) {
		this.card_passwd = card_passwd;
	}
	
	
}